# Name
Che-Jui (Jerry), Chang

# Feedback
This project is very challenging with different kinds of pointer. We need to think in multiple level to check the recursion is correct and check each statement in order to get to the correct logic and algorithm. In conclusion, I like this project and it feels awesome when you finally finish those complicated functions.

# Time to Completion
Around 24 hours

# Citations
Some geeks 2 geeks website for double linked list. Prof. Onsay's d2l's examples on recursion.