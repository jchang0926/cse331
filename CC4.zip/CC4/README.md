# Name
Che-Jui (Jerry), Chang

# Feedback
This CC is not as easy as we thought if we want to meet the requirement for time complexity. We have to think around the corner to get the final result of this CC.

# Time to Completion
Around 1-2 hours.

# Citations
https://codereview.stackexchange.com/questions/43344/retrieve-min-from-stack-in-o1