# Name
Che-Jui (Jerry), Chang

# Feedback
This is an interesting coding challenge, at first I didn't use the quick sort, then I kept failing the last test case. Then I asked my friend for some help and finally solve this challenge.

# Time to Completion
Around 1 hour

# Citations
My friend teach me quick sort and Prof. Onsay's pdf on d2l.