# Name
Che-Jui (Jerry), Chang

# Feedback
This project is very challenging in every aspect. we need to be really familiar with the black-red-tree
in order to complete it. Also, those zybook examples that Prof Onsay put on d2l really help for people who
does not have zybook.

# Time to Completion
I completed this project in around 4-5 days.

# Citations
d2l, zybook activities and some geeksforgeeks source.