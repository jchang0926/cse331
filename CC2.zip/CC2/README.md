# Name
Che-Jui (Jerry), Chang

# Feedback
This project is a little bit less confusing than the first cc, the reason why I can finish this cc is because that I'm getting used to python after a while. 

# Time to Completion
I finished this project around 2 hours

# Citations
None