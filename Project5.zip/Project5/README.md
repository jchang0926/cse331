# Name
Che-Jui (Jerry), Chang

# Feedback
This project is really fun, it helps us to understand priority queue
and max_heap and heap sort a lot better. All in all it's a good project. 

# Time to Completion
2-3 days

# Citations
Prof. Onsay's code from d2l, Zybooks