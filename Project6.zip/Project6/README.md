# Name
Che-Jui (Jerry), Chang

# Feedback
This project is really challenging and fun to solve. function before matrix2graph
are pretty easy, the most challenging part is to understand bfs and implement it.
In conclusion, this is a really good project for final project.

# Time to Completion
The first few functions took me around 1-2 hours to finish. for bfs, dfs, a_star and make_equivalence_relation
took about 1-2 days for each function mentioned above.

# Citations
https://www.geeksforgeeks.org/breadth-first-search-or-bfs-for-a-graph/
https://www.geeksforgeeks.org/depth-first-search-or-dfs-for-a-graph/
https://www.geeksforgeeks.org/a-search-algorithm/
https://www.geeksforgeeks.org/floyd-warshall-algorithm-dp-16/