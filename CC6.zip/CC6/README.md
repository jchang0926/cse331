# Name
Che-Jui (Jerry), Chang

# Feedback
This coding challenge is pretty easy to solve as long as we know how to use
yield and how to insert and pop and understand how does binary work.

# Time to Completion
Around 2 hours

# Citations
https://www.techiedelight.com/generate-binary-numbers-1-n/