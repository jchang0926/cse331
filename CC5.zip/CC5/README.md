# Name
Che-Jui (Jerry), Chang

# Feedback
This coding challenge is a little bit challenging. we have to check each root is the subtree of that
root is a balanced BST. If it is, we have to gather all the value and calculate the sum. return the biggest
sum of a subtree. 

# Time to Completion
This coding challenge took me about 5 hours to finish. I had to do some research online to get 
a better understanding about this coding challenge and how to approach it.

# Citations
https://www.geeksforgeeks.org/maximum-sub-tree-sum-in-a-binary-tree-such-that-the-sub-tree-is-also-a-bst/
