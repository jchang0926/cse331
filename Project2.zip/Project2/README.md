# Name
Che-Jui (Jerry), Chang

# Feedback
This project is a lot easier than project 1. We gotta implement merge sort and insertion sort. And calculate the inversion count. 

# Time to Completion
I completed it around 2 days. Took me some time to figure out how to make the find_function to run in order to pass the run time complexity.

# Citations
Geeks2Geeks, Prof. Onsay's lecture slides.