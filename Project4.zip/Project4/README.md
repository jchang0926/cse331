# Name
Che-Jui (Jerry), Chang

# Feedback
This project is really fun to code with. We gotta keep thinking about how does 
the trie works. I spend a lot of time drawing and debugging to really understand this
project. But anyway, it's fun to code this project.

# Time to Completion
This project took me about 4 days to code.

# Citations
Piazza, https://www.geeksforgeeks.org/auto-complete-feature-using-trie/
