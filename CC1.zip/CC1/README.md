# Name
Che-Jui (Jerry), Chang

# Feedback
This project is really fun, it helps me to get back to python after a while. It's a little bit harder than I think it is, but it's always fun to have a little challenge

# Time to Completion
It took me around 2 days to finish this project.'
 
# Citations
No