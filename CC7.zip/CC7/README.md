# **Name**
Che-Jui (Jerry), Chang

# **Feedback**
it's a fun little challenge, the first few functions are quite easy.
But the last function is a little bit tricker than the first few function,
 it takes a little bit more time to go through it and debug it.

# **Time to Complete**
Around 3 hours

#**Citations**
https://www.geeksforgeeks.org/python-sort-python-dictionaries-by-key-or-value/